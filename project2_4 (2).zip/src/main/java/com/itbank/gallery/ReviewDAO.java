package com.itbank.gallery;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface ReviewDAO {

	@Select("select * from product_review where review_pi = #{review_pi}")
	List<Product_ReviewDTO> selectReview(int review_pi);

}
