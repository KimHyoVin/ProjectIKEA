package com.itbank.gallery;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface GalleryDAO {

	@Select("SELECT PRODUCT.*, PRODUCT_IMAGE.IMAGE_FILENAME FROM PRODUCT JOIN PRODUCT_IMAGE ON PRODUCT_IDX = IMAGE_PI WHERE product_idx = #{product_idx}")
	List<GalleryDTO> selectList(int product_idx);
	
	@Select("select * from product where product_idx = #{product_idx}")
	ProductDTO selectObject(int product_idx);
	
	

}
