package com.itbank.gallery;

import java.util.Date;

public class Product_ReviewDTO {
	
	private int review_idx, review_pi, parent_review;
	private String review_writer, review_title, review_content, review_recommend;
	private double review_point_assembly, review_point_cosper, review_point_quality, review_point_shape, review_point_function;
	private Date review_regdate;
	
	public int getReview_idx() {
		return review_idx;
	}
	public void setReview_idx(int review_idx) {
		this.review_idx = review_idx;
	}
	public int getReview_pi() {
		return review_pi;
	}
	public void setReview_pi(int review_pi) {
		this.review_pi = review_pi;
	}
	public int getParent_review() {
		return parent_review;
	}
	public void setParent_review(int parent_review) {
		this.parent_review = parent_review;
	}
	public String getReview_writer() {
		return review_writer;
	}
	public void setReview_writer(String review_writer) {
		this.review_writer = review_writer;
	}
	public String getReview_title() {
		return review_title;
	}
	public void setReview_title(String review_title) {
		this.review_title = review_title;
	}
	public String getReview_content() {
		return review_content;
	}
	public void setReview_content(String review_content) {
		this.review_content = review_content;
	}
	public String getReview_recommend() {
		return review_recommend;
	}
	public void setReview_recommend(String review_recommend) {
		this.review_recommend = review_recommend;
	}
	public double getReview_point_assembly() {
		return review_point_assembly;
	}
	public void setReview_point_assembly(double review_point_assembly) {
		this.review_point_assembly = review_point_assembly;
	}
	public double getReview_point_cosper() {
		return review_point_cosper;
	}
	public void setReview_point_cosper(double review_point_cosper) {
		this.review_point_cosper = review_point_cosper;
	}
	public double getReview_point_quality() {
		return review_point_quality;
	}
	public void setReview_point_quality(double review_point_quality) {
		this.review_point_quality = review_point_quality;
	}
	public double getReview_point_shape() {
		return review_point_shape;
	}
	public void setReview_point_shape(double review_point_shape) {
		this.review_point_shape = review_point_shape;
	}
	public double getReview_point_function() {
		return review_point_function;
	}
	public void setReview_point_function(double review_point_function) {
		this.review_point_function = review_point_function;
	}
	public Date getReview_regdate() {
		return review_regdate;
	}
	public void setReview_regdate(Date review_regdate) {
		this.review_regdate = review_regdate;
	}
	
	
}
