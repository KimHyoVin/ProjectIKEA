package com.ikea.product;

import org.apache.ibatis.annotations.Insert;

//	PRODUCT
//		PRODUCT_IDX             NUMBER          DEFAULT PRODUCT_SEQ.NEXTVAL PRIMARY KEY,    -- 상품 인덱스
//	PRODUCT_CATEGORY        VARCHAR2(30)    NOT NULL,   -- 최하위 카테고리
//	PRODUCT_NAME            VARCHAR2(100)   NOT NULL,   -- 상품명
//	PRODUCT_DESC            VARCHAR2(200),   			-- 상품 상세구성 설명 EX) 침대프레임+침대헤드2
//	PRODUCT_SUMMARY         VARCHAR2(500),              -- 제품 간단 설명
//	PRODUCT_DETAILS         VARCHAR2(2000),             -- 제품 상세 설명
//	PRODUCT_LENGTH          NUMBER,                     -- 상품 길이(cm)
//	PRODUCT_WIDTH           NUMBER,                     -- 상품 너비(cm)
//	PRODUCT_HEIGHT          NUMBER,                     -- 상품 높이(cm)
//	PRODUCT_COLOR           VARCHAR2(50),               -- 상품 색상
//	PRODUCT_PRICE           NUMBER          NOT NULL,
//	PRODUCT_STOCK           NUMBER          NOT NULL,   -- 상품 재고
//		PRODUCT_SALEQUANTITY    NUMBER          DEFAULT 0,  -- 상품 판매량
//		PRODUCT_REGDATE         DATE            DEFAULT SYSDATE     -- 상품 등록일

//	PRODUCT_IMAGE
//		IMAGE_IDX               NUMBER          DEFAULT IMAGE_SEQ.NEXTVAL PRIMARY KEY,  -- 상품 이미지 인덱스
//		IMAGE_PI                NUMBER          NOT NULL,   -- FK : 상품 인덱스
//	IMAGE_FILENAME          VARCHAR2(128)   NOT NULL,   -- 이미지 파일명 (SHA-512를 사용할 경우, 딱 128자)
//	IMAGE_ISTHUMBNAIL1      CHAR(1)         CHECK(IMAGE_ISTHUMBNAIL1 IN ('Y', 'N')) NOT NULL,    -- 1번 대표 이미지인가? ('Y' OR 'N') 
//	IMAGE_ISTHUMBNAIL2      CHAR(1)         CHECK(IMAGE_ISTHUMBNAIL2 IN ('Y', 'N')) NOT NULL,    -- 2번 대표 이미지인가? ('Y' OR 'N') (마우스 오버시 나타나는 대표 이미지)
//		IMAGE_REGDATE           DATE            DEFAULT SYSDATE,     -- 이미지 등록일

public interface ProductDAO {

	@Insert("INSERT INTO PRODUCT (PRODUCT_CATEGORY, PRODUCT_NAME, PRODUCT_DESC, PRODUCT_SUMMARY, PRODUCT_DETAILS, "
			+ "PRODUCT_LENGTH, PRODUCT_WIDTH, PRODUCT_HEIGHT, PRODUCT_COLOR, PRODUCT_PRICE, PRODUCT_STOCK) "
			+ "VALUES ( #{product_category}, #{product_name}, #{product_desc}, #{product_summary}, #{product_details}, "
			+ "#{product_length}, #{product_width}, #{product_height}, #{product_color}, #{product_price}, #{product_stock} )")
	int productInsert(ProductDTO dto);
	
	@Insert("INSERT INTO PRODUCT_IMAGE (IMAGE_FILENAME, IMAGE_ISTHUMBNAIL1, IMAGE_ISTHUMBNAIL2)"
			+ " VALUES ( #{image_filename}, #{image_isthumbnail1}, #{image_isthumbnail2} )")
	int imageInsert(String image_filename, String image_isthumbnail1, String image_isthumbnail2);
	
}
