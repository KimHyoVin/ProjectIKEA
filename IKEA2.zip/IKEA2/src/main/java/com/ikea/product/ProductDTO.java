package com.ikea.product;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

//	PRODUCT
//		PRODUCT_IDX             NUMBER          DEFAULT PRODUCT_SEQ.NEXTVAL PRIMARY KEY,    -- 상품 인덱스
//	PRODUCT_CATEGORY        VARCHAR2(30)    NOT NULL,   -- 최하위 카테고리
//	PRODUCT_NAME            VARCHAR2(100)   NOT NULL,   -- 상품명
//	PRODUCT_DESC            VARCHAR2(200),   			-- 상품 상세구성 설명 EX) 침대프레임+침대헤드2
//	PRODUCT_SUMMARY         VARCHAR2(500),              -- 제품 간단 설명
//	PRODUCT_DETAILS         VARCHAR2(2000),             -- 제품 상세 설명
//	PRODUCT_LENGTH          NUMBER,                     -- 상품 길이(cm)
//	PRODUCT_WIDTH           NUMBER,                     -- 상품 너비(cm)
//	PRODUCT_HEIGHT          NUMBER,                     -- 상품 높이(cm)
//	PRODUCT_COLOR           VARCHAR2(50),               -- 상품 색상
//	PRODUCT_PRICE           NUMBER          NOT NULL,
//	PRODUCT_STOCK           NUMBER          NOT NULL,   -- 상품 재고
//	PRODUCT_SALEQUANTITY    NUMBER          DEFAULT 0,  -- 상품 판매량
//		PRODUCT_REGDATE         DATE            DEFAULT SYSDATE     -- 상품 등록일
//		
//	PRODUCT_IMAGE
//		IMAGE_IDX               NUMBER          DEFAULT IMAGE_SEQ.NEXTVAL PRIMARY KEY,  -- 상품 이미지 인덱스
//		IMAGE_PI                NUMBER          NOT NULL,   -- FK : 상품 인덱스
//	IMAGE_FILENAME          VARCHAR2(128)   NOT NULL,   -- 이미지 파일명 (SHA-512를 사용할 경우, 딱 128자)
//	IMAGE_ISTHUMBNAIL1      CHAR(1)         CHECK(IMAGE_ISTHUMBNAIL1 IN ('Y', 'N')) NOT NULL,    -- 1번 대표 이미지인가? ('Y' OR 'N') 
//	IMAGE_ISTHUMBNAIL2      CHAR(1)         CHECK(IMAGE_ISTHUMBNAIL2 IN ('Y', 'N')) NOT NULL,    -- 2번 대표 이미지인가? ('Y' OR 'N') (마우스 오버시 나타나는 대표 이미지)
//		IMAGE_REGDATE           DATE            DEFAULT SYSDATE,     -- 이미지 등록일

public class ProductDTO {
	
	private String product_category, product_name, product_desc, product_summary, product_details, product_color;
	private int product_length, product_width, product_height, product_price, product_stock, product_salequantity;
	
	private String image_filename, image_isthumbnail1, image_isthumbnail2;
	
	private List<MultipartFile> imageFile;

	public String getProduct_category() {
		return product_category;
	}
	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getProduct_desc() {
		return product_desc;
	}
	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}
	public String getProduct_summary() {
		return product_summary;
	}
	public void setProduct_summary(String product_summary) {
		this.product_summary = product_summary;
	}
	public String getProduct_details() {
		return product_details;
	}
	public void setProduct_details(String product_details) {
		this.product_details = product_details;
	}
	public String getProduct_color() {
		return product_color;
	}
	public void setProduct_color(String product_color) {
		this.product_color = product_color;
	}
	public int getProduct_length() {
		return product_length;
	}
	public void setProduct_length(int product_length) {
		this.product_length = product_length;
	}
	public int getProduct_width() {
		return product_width;
	}
	public void setProduct_width(int product_width) {
		this.product_width = product_width;
	}
	public int getProduct_height() {
		return product_height;
	}
	public void setProduct_height(int product_height) {
		this.product_height = product_height;
	}
	public int getProduct_price() {
		return product_price;
	}
	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}
	public int getProduct_stock() {
		return product_stock;
	}
	public void setProduct_stock(int product_stock) {
		this.product_stock = product_stock;
	}
	public int getProduct_salequantity() {
		return product_salequantity;
	}
	public void setProduct_salequantity(int product_salequantity) {
		this.product_salequantity = product_salequantity;
	}
	public String getImage_filename() {
		return image_filename;
	}
	public void setImage_filename(String image_filename) {
		this.image_filename = image_filename;
	}
	public String getImage_isthumbnail1() {
		return image_isthumbnail1;
	}
	public void setImage_isthumbnail1(String image_isthumbnail1) {
		this.image_isthumbnail1 = image_isthumbnail1;
	}
	public String getImage_isthumbnail2() {
		return image_isthumbnail2;
	}
	public void setImage_isthumbnail2(String image_isthumbnail2) {
		this.image_isthumbnail2 = image_isthumbnail2;
	}
	public List<MultipartFile> getImageFile() {
		return imageFile;
	}
	public void setImageFile(List<MultipartFile> imageFile) {
		this.imageFile = imageFile;
	}
}
