package com.ikea.service;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.ikea.product.ProductDAO;
import com.ikea.product.ProductDTO;

@Service
public class FileUploadService {

	@Autowired private ProductDAO dao;
	private String imageRepoFolder = "D:\\IMAGE_TEST";
	
	public FileUploadService() {
		File dir = new File(imageRepoFolder);
		if(dir.exists() && dir.isFile()) dir.delete();
		if(dir.exists() == false) dir.mkdirs();
	}

	public int productInsert(ProductDTO dto) {
		return dao.productInsert(dto);
	}
	
	public int imageInsert(List<MultipartFile> imageFile) {
		
		// imageFile.forEach(file -> System.out.println("서비스가 받은 파일명 : " + file.getOriginalFilename()));
		for (int i = 0; i < imageFile.size(); i++) {
			if (imageFile.get(i).getSize() != 0) {
				System.out.println("등록될 파일" + (i + 1) + imageFile.get(i).getOriginalFilename());
			}
			imageFile.get(i);
		}
		return 0;
	}
}
