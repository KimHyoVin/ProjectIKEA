package com.ikea.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class AddProductController {
	
//	@Autowired private AddProductService aps;
	
	@GetMapping("/addproduct")
	public void add() {}
	
//	@PostMapping
//	public int insert(ProductDTO dto) {
//		return aps.insert(dto);
//	}
	
}
