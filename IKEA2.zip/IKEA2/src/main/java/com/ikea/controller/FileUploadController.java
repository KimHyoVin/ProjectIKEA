package com.ikea.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.ikea.product.ProductDAO;
import com.ikea.product.ProductDTO;
import com.ikea.service.FileUploadService;

@Controller
public class FileUploadController {

	@Autowired
	private FileUploadService fus;

	@RequestMapping("/uploadForm")
	public void form() {}

	@PostMapping("/upload")
	public ModelAndView upload(ProductDTO dto) throws Exception {
		List<MultipartFile> imageFile = dto.getImageFile();

		fus.productInsert(dto);		// 상품 등록
		fus.imageInsert(imageFile);	// 이미지(들) 등록
		
		ModelAndView mav = new ModelAndView("result");
		return mav;
	}


}
