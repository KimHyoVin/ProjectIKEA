
//const cpath = '${cpath}'
const cpath = 'http://localhost:8080/project_4zone/'



function convert(dto) {

    const item = document.createElement('div')
    // item.classList.add('item')
    item.classList.add('sect3_slide')
    item.classList.add('swiper-slide')
    
    const sect3_teaser_container = document.createElement('div')
    // const productLink = document.createElement('a')
    const sect3_teaser_img = document.createElement('div')
    const sect3_teaser_content = document.createElement('div') 

    sect3_teaser_img.classList.add('sect3_teaser_img')
    sect3_teaser_content.classList.add('sect3_teaser_content')
    sect3_teaser_container.classList.add('sect3_teaser_container')
    // productLink.setAttribute('href','www.naver.com')
    item.innerHTML = ''
    sect3_teaser_container.appendChild(sect3_teaser_img)
    sect3_teaser_container.appendChild(sect3_teaser_content)
    item.appendChild(sect3_teaser_container)
    
    sect3_teaser_img.innerHTML += `<img class="sect3_banner1" src="${cpath}/upload/${dto.image_filename}">`
    

    sect3_teaser_content.innerHTML += `<div class="sect3_product_name"><h3>${dto.product_name}</h3></div>
                                    <div class="sect3_product_category"><span>${dto.product_category}</span></div>
                                    <div class="sect3_product_price"><span>￦${dto.product_price}</span></div>`
    
    return item
}
async function selectH(event) {
    // const sect3_slide = document.querySelector('.sect3_slide')
    const wrapper = document.querySelector('.sect3_main .swiper-wrapper')
    const url = 'http://localhost:8080/project_4zone/project1'
    return await fetch(url)
    .then(resp => resp.json())
    .then(json => {
        console.log(json)
        json.forEach(dto => wrapper.appendChild(convert(dto)))

    })
}

function thumb(dto) {
    const imte = document.querySelector('.item')
    const sect3_teaser_content = document.querySelector('.sect3_teaser_content')
    const sect3_teaser_img = document.querySelector('.sect3_teaser_img')
    const banner = document.createElement('img')
    banner.classList.add('sect3_banner2')
    banner.src=`${cpath}/upload/${dto.image_filename}`
    sect3_teaser_img.appendChild(banner)
    sect3_teaser_container.appendChild(sect3_teaser_img)
    item.appendChild(sect3_teaser_img)
    item.appendChild(sect3_teaser_content)

    return item
}
async function thumbnailH(event) {
    // const sect3_slide = document.querySelector('.sect3_slide')
    const wrapper = document.querySelector('.sect3_main .swiper-wrapper')
    const url = 'http://localhost:8080/project_4zone/project2'
    
    await fetch(url)
    .then(resp => resp.json())
    .then(json => {
        console.log(json)
        json.forEach(dto => wrapper.appendChild(thumb(dto)))

    })
}


//		PRODUCT_NAME            VARCHAR2(100)   UNIQUE NOT NULL,    -- 상품명
//		PRODUCT_CATEGORY        VARCHAR2(20)    NOT NULL,   -- 최하위 카테고리
//		PRODUCT_PRICE           NUMBER          NOT NULL,
//		PRODUCT_DESC            VARCHAR2(2000),   			-- 상품 설명

//		PRODUCT_IDX             NUMBER          DEFAULT PRODUCT_SEQ.NEXTVAL PRIMARY KEY,    -- 상품 인덱스
//		PRODUCT_LENGTH          NUMBER,                     -- 상품 길이(cm)
//		PRODUCT_WIDTH           NUMBER,                     -- 상품 너비(cm)
//		PRODUCT_HEIGHT          NUMBER,                     -- 상품 높이(cm)
//		PRODUCT_STOCK           NUMBER          NOT NULL,   -- 상품 재고
//		PRODUCT_COLOR           VARCHAR2(50),               -- 상품 색상
//		PRODUCT_SALEQUANTITY    NUMBER          DEFAULT 0,  -- 상품 판매량
//		PRODUCT_REGDATE         DATE            DEFAULT SYSDATE     -- 상품 등록일
//		);
//      image_filename

