async function test1() {

  await selectH()
  
  var sect3_teaser = new Swiper(".sect3_teaser", {
    slidesPerView: 4.5,
    spaceBetween: 30,
    slidesPerGroup: 3,
    freeMode: true,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
        },
        scrollbar: {
          el: ".swiper-scrollbar",
        },
    });
    
  await thumbnailH()
}