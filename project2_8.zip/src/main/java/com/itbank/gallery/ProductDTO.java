package com.itbank.gallery;

import java.util.Date;

public class ProductDTO {
	private int product_idx, product_length, product_width, product_height, product_price, product_stock, product_salequantity;
	private String product_category, product_name, product_desc, product_summary, product_details, product_color;
	private Date product_regdate;
	
	public int getProduct_idx() {
		return product_idx;
	}
	public void setProduct_idx(int product_idx) {
		this.product_idx = product_idx;
	}
	public int getProduct_length() {
		return product_length;
	}
	public void setProduct_length(int product_length) {
		this.product_length = product_length;
	}
	public int getProduct_width() {
		return product_width;
	}
	public void setProduct_width(int product_width) {
		this.product_width = product_width;
	}
	public int getProduct_height() {
		return product_height;
	}
	public void setProduct_height(int product_height) {
		this.product_height = product_height;
	}
	public int getProduct_price() {
		return product_price;
	}
	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}
	public int getProduct_stock() {
		return product_stock;
	}
	public void setProduct_stock(int product_stock) {
		this.product_stock = product_stock;
	}
	public int getProduct_salequantity() {
		return product_salequantity;
	}
	public void setProduct_salequantity(int product_salequantity) {
		this.product_salequantity = product_salequantity;
	}
	public String getProduct_category() {
		return product_category;
	}
	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getProduct_desc() {
		return product_desc;
	}
	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}
	public String getProduct_summary() {
		return product_summary;
	}
	public void setProduct_summary(String product_summary) {
		this.product_summary = product_summary;
	}
	public String getProduct_details() {
		return product_details;
	}
	public void setProduct_details(String product_details) {
		this.product_details = product_details;
	}
	public String getProduct_color() {
		return product_color;
	}
	public void setProduct_color(String product_color) {
		this.product_color = product_color;
	}
	public Date getProduct_regdate() {
		return product_regdate;
	}
	public void setProduct_regdate(Date product_regdate) {
		this.product_regdate = product_regdate;
	}
	
	
}
