package com.itbank.gallery;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class GalleryDTO {

	private int image_idx, product_idx;
	private String image_filename;
	private String image_isthumbnall1;
	private String image_isthumbnall2;
	private Date image_regdate;
	private MultipartFile file;
	public int getImage_idx() {
		return image_idx;
	}
	public void setImage_idx(int image_idx) {
		this.image_idx = image_idx;
	}
	public int getProduct_idx() {
		return product_idx;
	}
	public void setProduct_idx(int product_idx) {
		this.product_idx = product_idx;
	}
	public String getImage_filename() {
		return image_filename;
	}
	public void setImage_filename(String image_filename) {
		this.image_filename = image_filename;
	}
	public String getImage_isthumbnall1() {
		return image_isthumbnall1;
	}
	public void setImage_isthumbnall1(String image_isthumbnall1) {
		this.image_isthumbnall1 = image_isthumbnall1;
	}
	public String getImage_isthumbnall2() {
		return image_isthumbnall2;
	}
	public void setImage_isthumbnall2(String image_isthumbnall2) {
		this.image_isthumbnall2 = image_isthumbnall2;
	}
	public Date getImage_regdate() {
		return image_regdate;
	}
	public void setImage_regdate(Date image_regdate) {
		this.image_regdate = image_regdate;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	
	
	
}
