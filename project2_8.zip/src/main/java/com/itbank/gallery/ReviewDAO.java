package com.itbank.gallery;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface ReviewDAO {

	@Select("select * from product_review where review_pi = #{review_pi}")
	List<Product_ReviewDTO> selectReview(int review_pi);
	
	@Select("select avg(review_point_assembly + review_point_cosper + review_point_quality + review_point_shape + review_point_function) / 5 as all_avg from product_review where review_pi = #{review_pi}")
	List<Product_ReviewDTO> selectReviewStar(int review_pi);
	
	@Select("select count(*) from product_review where review_pi = #{review_pi}")
	int selectReviewCount(int review_pi);
	
	@Delete("delete product_review where review_idx = #{review_idx}")
	int deleteReview(int review_idx);
	
	@Insert("insert into product_review (review_pi, review_content) "
			+ "values (#{review_pi}, #{review_content})")
	int insertReview(Product_ReviewDTO dto);
	

}

