package com.itbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.itbank.gallery.GalleryDTO;
import com.itbank.gallery.ProductDTO;
import com.itbank.gallery.Product_ReviewDTO;
import com.itbank.service.GalleryService;

@Controller

public class GalleryController {
	
	@Autowired private GalleryService galleryService;
	
	@GetMapping("/gallery/{product_idx}")
	@ResponseBody
	public List<GalleryDTO> list(@PathVariable int product_idx) {
		return galleryService.selectList(product_idx);
	}
	
	@GetMapping("/gallery/view/{product_idx}")
	public ModelAndView selectObject(@PathVariable int product_idx) {
		ModelAndView mav = new ModelAndView();
	    mav.setViewName("view");
	    ProductDTO dto = galleryService.selectObject(product_idx);
	    mav.addObject("dto" , dto);
	    
	    List<Product_ReviewDTO> reviewList = galleryService.selectReview(product_idx);
		mav.addObject("reviewList", reviewList);
		
		int reviewCount = galleryService.selectReviewCount(product_idx);
		mav.addObject("reviewCount", reviewCount);
		
		List<Product_ReviewDTO> reviewListStar = galleryService.selectReviewStar(product_idx);
		mav.addObject("reviewListStar", reviewListStar);
	    
	    return mav;
	}
	
	@GetMapping("/gallery/deleteReply/{product_idx}/{review_idx}")
	public String deleteReview(@PathVariable int product_idx, @PathVariable int review_idx) {
		int row = galleryService.deleteReview(review_idx);
		System.out.println(row != 0 ? "댓글 삭제 성공" : "댓글 삭제 실패");
		return "redirect:/gallery/view/" + product_idx;
	}
	
	@PostMapping("/gallery/view/{product_idx}")
	public String reviewWrite(Product_ReviewDTO dto) {
		int row = galleryService.insertReview(dto);
		System.out.println(row != 0 ? "리뷰 작성 성공" : "리뷰 작성 실패");
		return "redirect:/gallery/view/" + dto.getReview_pi();
	}
	

}
