package com.itbank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.itbank.gallery.GalleryDAO;
import com.itbank.gallery.GalleryDTO;
import com.itbank.gallery.ProductDTO;
import com.itbank.gallery.Product_ReviewDTO;
import com.itbank.gallery.ReviewDAO;

@Service
public class GalleryService {

	@Autowired private GalleryDAO dao;

	public List<GalleryDTO> selectList(int product_idx) {
		return dao.selectList(product_idx);
	}

	public ProductDTO selectObject(int product_idx) {
		return dao.selectObject(product_idx);
	}
	
	
	@Autowired private ReviewDAO reviewdao;
	
	public List<Product_ReviewDTO> selectReview(int product_idx) {
		return reviewdao.selectReview(product_idx);
	}

	public List<Product_ReviewDTO> selectReviewStar(int product_idx) {
		return reviewdao.selectReviewStar(product_idx);
	}

	public int selectReviewCount(int product_idx) {
		return reviewdao.selectReviewCount(product_idx);
	}

	public int deleteReview(int review_idx) {
		return reviewdao.deleteReview(review_idx);
	}

	public int insertReview(Product_ReviewDTO dto) {
		return reviewdao.insertReview(dto);
	}

	
}
